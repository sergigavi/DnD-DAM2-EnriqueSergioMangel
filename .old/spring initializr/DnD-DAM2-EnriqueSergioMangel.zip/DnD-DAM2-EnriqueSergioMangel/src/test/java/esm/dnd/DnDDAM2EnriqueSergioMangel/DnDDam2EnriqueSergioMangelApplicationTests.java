package esm.dnd.DnDDAM2EnriqueSergioMangel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DnDDam2EnriqueSergioMangelApplicationTests {

	@Test
	void contextLoads() {
	}

}
